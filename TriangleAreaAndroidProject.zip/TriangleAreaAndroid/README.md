# Calculate Triangle Area — Android project

A native Android calculator styled after the supplied reference image. It has three side-length fields, **Clean** and **Calculate** buttons, and computes area from all three side lengths using Heron's formula.

## Validation and comfort features

- Empty fields show inline **Required** messages.
- Zero and negative side lengths are rejected with a message below the relevant field.
- Malformed, non-finite, and out-of-range values are handled without crashing.
- Inputs that cannot form a triangle are rejected with an explanation of the triangle inequality, and the longest side is highlighted.
- The area is computed with a numerically scaled, factored form of Heron's formula to avoid avoidable intermediate overflow.
- Errors and old results clear as the user edits values; successful calculations dismiss the keyboard.
- The keyboard's Next action advances between fields and Done calculates.
- Clean resets values, errors, and results, and returns focus to Side A.
- Supports a comma or period as the decimal separator when only one separator is present.
- Result labels include square units and show the semi-perimeter as extra context.

## Build an APK with Android Studio

1. Unzip this project.
2. Open the `TriangleAreaAndroid` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Build through GitHub Actions

Push the project to a GitHub repository. Open **Actions > Build Android APK > Run workflow**. Once the workflow succeeds, download the `TriangleArea-debug-apk` artifact.

This ZIP contains the Android Studio project and build workflow; it does not itself contain a precompiled APK.
