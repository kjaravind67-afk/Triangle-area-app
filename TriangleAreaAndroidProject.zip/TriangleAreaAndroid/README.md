# Triangle Area — Android project

Native Android triangle-area calculator with a custom minimalist blue triangle app icon.

## Build
The GitHub Actions workflow builds a debug APK. The APK artifact can be downloaded from the successful workflow run.

Area is calculated using Heron's formula from the three side lengths. Clean clears the inputs and result.
