package com.example.trianglearea;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.graphics.Rect;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class MainActivity extends Activity {
    private static final int TEAL = Color.rgb(32, 185, 197);
    private static final int TEAL_DARK = Color.rgb(27, 166, 177);
    private static final int ORANGE = Color.rgb(230, 160, 75);
    private static final int INK = Color.rgb(36, 50, 56);
    private static final int MUTED = Color.rgb(104, 119, 123);
    private static final int ERROR = Color.rgb(177, 49, 42);
    private static final int PAPER = Color.rgb(247, 251, 252);
    private static final int LINE = Color.rgb(217, 225, 227);

    private EditText[] sideInputs;
    private TextView[] fieldErrors;
    private TextView statusMessage;
    private TextView areaResult;
    private TextView detailResult;
    private LinearLayout resultBox;
    private ScrollView scrollView;
    private boolean updatingErrors = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(PAPER);
        getWindow().setNavigationBarColor(PAPER);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        );
        buildUi();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable background(int color, int strokeColor, int strokeWidth, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        if (strokeWidth > 0) drawable.setStroke(dp(strokeWidth), strokeColor);
        return drawable;
    }

    private TextView makeText(String value, int size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private void buildUi() {
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(PAPER);
        screen.setPadding(dp(12), dp(10), dp(12), dp(8));

        TextView title = makeText("Calculate Triangle Area", 22, INK);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(6), dp(12), dp(6), dp(10));
        screen.addView(title);

        TextView subtitle = makeText("Enter the length of each side", 14, MUTED);
        subtitle.setPadding(dp(6), 0, dp(6), dp(18));
        screen.addView(subtitle);

        scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setClipToPadding(false);
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(2), 0, dp(2), dp(12));

        sideInputs = new EditText[3];
        fieldErrors = new TextView[3];
        String[] labels = {"Side A", "Side B", "Side C"};
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            LinearLayout field = new LinearLayout(this);
            field.setOrientation(LinearLayout.VERTICAL);

            TextView label = makeText(labels[i], 18, INK);
            label.setPadding(dp(2), dp(5), 0, dp(6));
            field.addView(label);

            EditText input = makeInput(labels[i]);
            input.setImeOptions(i == 2 ? EditorInfo.IME_ACTION_DONE : EditorInfo.IME_ACTION_NEXT);
            sideInputs[i] = input;
            field.addView(input, new LinearLayout.LayoutParams(-1, dp(54)));

            TextView errorText = makeText("", 12, ERROR);
            errorText.setPadding(dp(3), dp(4), dp(3), dp(1));
            errorText.setVisibility(View.GONE);
            fieldErrors[i] = errorText;
            field.addView(errorText);

            LinearLayout.LayoutParams fieldParams = new LinearLayout.LayoutParams(-1, -2);
            fieldParams.bottomMargin = dp(12);
            fields.addView(field, fieldParams);

            input.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_NEXT && index < 2) {
                    sideInputs[index + 1].requestFocus();
                    return true;
                }
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    calculate();
                    return true;
                }
                return false;
            });
            input.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (updatingErrors) return;
                    if (statusMessage != null && statusMessage.getText().toString().startsWith("Invalid triangle.")) {
                        clearAllFieldErrors();
                    }
                    clearFieldError(index);
                    clearStatus();
                    hideResult();
                }
                @Override public void afterTextChanged(Editable editable) { }
            });
        }

        statusMessage = makeText("", 14, ERROR);
        statusMessage.setPadding(dp(10), dp(10), dp(10), dp(10));
        statusMessage.setBackground(background(Color.rgb(255, 241, 239), Color.rgb(245, 205, 200), 1, 5));
        statusMessage.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        statusMessage.setVisibility(View.GONE);
        fields.addView(statusMessage, new LinearLayout.LayoutParams(-1, -2));

        resultBox = new LinearLayout(this);
        resultBox.setOrientation(LinearLayout.VERTICAL);
        resultBox.setPadding(dp(12), dp(12), dp(12), dp(10));
        resultBox.setBackground(background(Color.rgb(232, 248, 249), TEAL, 2, 5));
        resultBox.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        resultBox.setVisibility(View.GONE);

        TextView resultLabel = makeText("CALCULATED AREA", 12, MUTED);
        resultLabel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        resultBox.addView(resultLabel);
        areaResult = makeText("", 27, INK);
        areaResult.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        areaResult.setPadding(0, dp(3), 0, dp(3));
        resultBox.addView(areaResult);
        detailResult = makeText("", 13, MUTED);
        resultBox.addView(detailResult);
        fields.addView(resultBox, new LinearLayout.LayoutParams(-1, -2));

        TextView example = makeText("Example: 3, 4, 5 → area = 6 square units", 12, MUTED);
        example.setGravity(Gravity.CENTER);
        example.setPadding(dp(4), dp(16), dp(4), dp(6));
        fields.addView(example);

        scrollView.addView(fields);
        screen.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(8), 0, dp(6));
        Button cleanButton = makeButton("Clean", false);
        Button calculateButton = makeButton("Calculate", true);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(0, dp(54), 1f);
        buttonParams.setMargins(dp(1), 0, dp(1), 0);
        actions.addView(cleanButton, buttonParams);
        actions.addView(calculateButton, new LinearLayout.LayoutParams(buttonParams));
        screen.addView(actions);

        TextView footer = makeText("Area is measured in square units.", 12, MUTED);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(2), 0, dp(3));
        screen.addView(footer);

        cleanButton.setOnClickListener(v -> cleanInputs());
        calculateButton.setOnClickListener(v -> calculate());
        setContentView(screen);
    }

    private EditText makeInput(String label) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(18);
        input.setTextColor(INK);
        input.setHint("Enter " + label.toLowerCase() + " length");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setPadding(dp(12), 0, dp(12), 0);
        input.setSelectAllOnFocus(false);
        input.setBackground(background(Color.WHITE, LINE, 1, 4));
        input.setContentDescription(label + " length");
        return input;
    }

    private Button makeButton(String label, boolean primary) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(16);
        button.setTypeface(Typeface.DEFAULT, primary ? Typeface.BOLD : Typeface.NORMAL);
        button.setTextColor(INK);
        button.setMinHeight(dp(54));
        button.setBackground(background(TEAL, TEAL_DARK, 1, 4));
        return button;
    }

    private void setFieldError(int index, String message) {
        fieldErrors[index].setText(message);
        fieldErrors[index].setVisibility(View.VISIBLE);
        sideInputs[index].setBackground(background(Color.WHITE, ERROR, 2, 4));
        sideInputs[index].setContentDescription("Side " + (char) ('A' + index) + ". Error: " + message);
    }

    private void clearFieldError(int index) {
        if (fieldErrors == null || fieldErrors[index] == null) return;
        fieldErrors[index].setText("");
        fieldErrors[index].setVisibility(View.GONE);
        sideInputs[index].setBackground(background(Color.WHITE, LINE, 1, 4));
        sideInputs[index].setContentDescription("Side " + (char) ('A' + index) + " length");
    }

    private void clearAllFieldErrors() {
        updatingErrors = true;
        for (int i = 0; i < 3; i++) clearFieldError(i);
        updatingErrors = false;
    }

    private void showStatus(String message) {
        statusMessage.setText(message);
        statusMessage.setVisibility(View.VISIBLE);
    }

    private void clearStatus() {
        if (statusMessage != null) {
            statusMessage.setText("");
            statusMessage.setVisibility(View.GONE);
        }
    }

    private void hideResult() {
        if (resultBox != null) resultBox.setVisibility(View.GONE);
    }

    private void calculate() {
        clearAllFieldErrors();
        clearStatus();
        hideResult();

        double[] sides = new double[3];
        boolean valid = true;
        int firstInvalid = -1;
        for (int i = 0; i < sideInputs.length; i++) {
            String raw = sideInputs[i].getText().toString().trim();
            if (raw.isEmpty()) {
                setFieldError(i, "Required. Enter a side length.");
                valid = false;
            } else {
                try {
                    String normalized = raw;
                    if (normalized.indexOf(',') >= 0 && normalized.indexOf('.') < 0
                            && normalized.indexOf(',') == normalized.lastIndexOf(',')) {
                        normalized = normalized.replace(',', '.');
                    }
                    sides[i] = Double.parseDouble(normalized);
                    if (Double.isNaN(sides[i]) || Double.isInfinite(sides[i])) {
                        setFieldError(i, "Enter a finite number.");
                        valid = false;
                    } else if (sides[i] <= 0) {
                        setFieldError(i, "Side length must be greater than 0.");
                        valid = false;
                    }
                } catch (NumberFormatException ex) {
                    setFieldError(i, "Enter a valid number, such as 4 or 2.5.");
                    valid = false;
                }
            }
            if (!valid && firstInvalid == -1 && fieldErrors[i].getVisibility() == View.VISIBLE) firstInvalid = i;
        }

        if (!valid) {
            showStatus("Invalid amount. Check the highlighted field(s) and try again.");
            focusField(firstInvalid < 0 ? 0 : firstInvalid);
            return;
        }

        // Sort so a is the longest side. The equivalent triangle inequality
        // a - b < c avoids overflowing when b + c is extremely large.
        double[] sorted = sides.clone();
        java.util.Arrays.sort(sorted);
        double c = sorted[0];
        double b = sorted[1];
        double a = sorted[2];
        if (!(a - b < c)) {
            int longestIndex = indexOfLongestSide(sides);
            setFieldError(longestIndex, "Too long to form a triangle with the other sides.");
            showStatus("Invalid triangle. The sum of the two shorter sides must be greater than the longest side.");
            focusField(longestIndex);
            return;
        }

        // Kahan's factored Heron formula, scaled to keep intermediate values
        // stable for ordinary inputs and many very large or very small inputs.
        double scale = a;
        double an = a / scale;
        double bn = b / scale;
        double cn = c / scale;
        double first = an + (bn + cn);
        double second = cn - (an - bn);
        double third = cn + (an - bn);
        double fourth = an + (bn - cn);
        double normalizedProduct = first * second * third * fourth;
        double normalizedArea = 0.25 * Math.sqrt(Math.max(0.0, normalizedProduct));
        double area = scale * (scale * normalizedArea);
        double semiperimeter = a / 2.0 + b / 2.0 + c / 2.0;

        if (Double.isNaN(area) || Double.isInfinite(area) || area <= 0.0) {
            showStatus("These side lengths are outside the calculator's numeric range. Try smaller values (or values that are not extremely tiny).");
            return;
        }

        areaResult.setText(formatNumber(area) + " square units");
        detailResult.setText("Semi-perimeter: " + formatNumber(semiperimeter));
        resultBox.setVisibility(View.VISIBLE);
        dismissKeyboard();
    }

    private int indexOfLongestSide(double[] sides) {
        int longest = 0;
        for (int i = 1; i < sides.length; i++) {
            if (sides[i] > sides[longest]) longest = i;
        }
        return longest;
    }

    private String formatNumber(double value) {
        if (value == 0.0) return "0";
        if (Math.abs(value) >= 1.0e9 || Math.abs(value) < 1.0e-5) {
            return String.format(Locale.getDefault(), "%.6g", value);
        }
        DecimalFormat format = new DecimalFormat("0.########", DecimalFormatSymbols.getInstance(Locale.getDefault()));
        format.setGroupingUsed(false);
        return format.format(value);
    }

    private void focusField(int index) {
        if (index < 0 || index >= sideInputs.length) index = 0;
        final int focusIndex = index;
        sideInputs[focusIndex].requestFocus();
        scrollView.post(() -> {
            Rect rect = new Rect();
            sideInputs[focusIndex].getDrawingRect(rect);
            scrollView.offsetDescendantRectToMyCoords(sideInputs[focusIndex], rect);
            scrollView.smoothScrollTo(0, Math.max(0, rect.top - dp(24)));
        });
    }

    private void dismissKeyboard() {
        View focused = getCurrentFocus();
        if (focused != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
            focused.clearFocus();
        }
    }

    private void cleanInputs() {
        for (EditText input : sideInputs) input.setText("");
        clearAllFieldErrors();
        clearStatus();
        hideResult();
        sideInputs[0].requestFocus();
        sideInputs[0].post(() -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(sideInputs[0], InputMethodManager.SHOW_IMPLICIT);
        });
        scrollView.smoothScrollTo(0, 0);
    }
}
